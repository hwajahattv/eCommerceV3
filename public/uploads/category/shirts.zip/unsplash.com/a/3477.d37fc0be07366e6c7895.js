"use strict";
(globalThis.webpackChunkunsplash_web = globalThis.webpackChunkunsplash_web || []).push([
    [3477], {
        1931: (t, e, o) => {
            o.d(e, {
                t: () => v
            });
            var n = o(3735),
                r = o(90071),
                a = o(11324),
                s = o(53084),
                u = o(14594),
                c = o(47725),
                l = o(12164),
                h = o(2739),
                i = o(60173),
                g = o(66952),
                p = o(8844),
                b = o(5845),
                z = o(56673),
                G = o(22222),
                d = o(78268),
                k = o(94597),
                w = o(34132);
            const f = () => {
                    const t = (0, w.aK)(),
                        e = (0, d.k)();
                    return (0, G.P1)(((t, o) => {
                        let {
                            routeData: n
                        } = o;
                        return e(n)
                    }), ((e, o) => {
                        let {
                            locationState: n
                        } = o;
                        return t(e, n)
                    }), (0, n.ls)(l.gz, l.tS((t => {
                        let [e, {
                            photoIds: o
                        }] = t;
                        const r = (0, n.zG)(o, k.cq5(e));
                        return (0, n.zG)(r, l.UI((t => o.length - (t + 1))))
                    }))))
                },
                v = t => {
                    const e = (0, n.zG)(g.qp(b.Q4), i.Gg),
                        o = g.Ye((() => (0, n.zG)(e, r.Ep, p.Vw.fromPath, l.gf)), [e]),
                        G = (0, u.LL)(e),
                        d = g.Ye(f, []),
                        k = (0, c.v)((t => d(t, {
                            routeData: o,
                            locationState: G
                        }))),
                        w = (0, a.m)((t => {
                            const e = (0, n.zG)(t, h.UI((t => t[0])), h.xb());
                            return (0, n.zG)(e, h.UI(l.Gg((t => t <= 6))), h.xb(), h.hX((t => t)))
                        }), [k]);
                    return g.az(z.Z, { ...t,
                        intersectionObserverRoot: s.H3,
                        notifier$: w
                    })
                }
        },
        46201: (t, e, o) => {
            o.d(e, {
                X: () => c
            });
            var n = o(3735),
                r = o(73124),
                a = o(12164),
                s = o(19838),
                u = o(66952);
            const c = t => {
                let {
                    index: e,
                    photo: o
                } = t;
                const {
                    factory: c
                } = (0, r.g)(s.ug._y);
                return u.Ye((() => (0, n.zG)(c({
                    index: e,
                    photo: o
                }), a.g_((() => o), (0, n.ls)(s.hm, s.aX(o))))), [c, o, e])
            }
        }
    }
]);
//# sourceMappingURL=3477.d37fc0be07366e6c7895.js.map